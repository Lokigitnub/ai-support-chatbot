"""One function, two providers. Switch with LLM_PROVIDER in .env."""
import os

from dotenv import load_dotenv

load_dotenv()


def generate(system, messages):
    if os.getenv("LLM_PROVIDER", "ollama") == "claude":
        from anthropic import Anthropic

        response = Anthropic().messages.create(
            model="claude-sonnet-5-5",
            max_tokens=500,
            system=system,
            messages=messages,
        )
        return response.content[0].text

    import ollama

    response = ollama.chat(
        model=os.getenv("OLLAMA_MODEL", "llama3.2"),
        messages=[{"role": "system", "content": system}, *messages],
    )
    return response["message"]["content"]
