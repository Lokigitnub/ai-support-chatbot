"""Reads every .md file in data/, chunks it, and stores embeddings in Chroma.
Run once (and again whenever you change the docs):  python -m app.ingest
"""
from pathlib import Path

import chromadb

DATA_DIR = Path("data")
DB_DIR = "chroma_db"


def chunk_text(text, size=500, overlap=100):
    """Split text into overlapping pieces so no idea is cut at a boundary."""
    chunks, start = [], 0
    while start < len(text):
        chunks.append(text[start:start + size])
        start += size - overlap
    return chunks


def ingest():
    db = chromadb.PersistentClient(path=DB_DIR)
    try:
        db.delete_collection("support_docs")  # rebuild fresh each run
    except Exception:
        pass
    collection = db.create_collection("support_docs")

    ids, docs, metas = [], [], []
    for file in DATA_DIR.glob("*.md"):
        text = file.read_text(encoding="utf-8")
        for i, chunk in enumerate(chunk_text(text)):
            ids.append(f"{file.stem}-{i}")
            docs.append(chunk)
            metas.append({"source": file.name})

    collection.add(ids=ids, documents=docs, metadatas=metas)
    print(f"Stored {len(docs)} chunks from {DATA_DIR}/")


if __name__ == "__main__":
    ingest()
