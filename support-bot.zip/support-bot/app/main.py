from fastapi import FastAPI
from pydantic import BaseModel

from app.rag import answer

app = FastAPI(title="AI Customer Support Chatbot")


class ChatRequest(BaseModel):
    messages: list[dict]  # [{"role": "user", "content": "..."}]


@app.get("/")
def health():
    return {"status": "ok", "docs": "/docs"}


@app.post("/chat")
def chat(body: ChatRequest):
    reply, sources = answer(body.messages)
    return {"reply": reply, "sources": sources}
