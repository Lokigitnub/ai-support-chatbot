"""RAG: retrieve the most relevant chunks, then let the LLM answer from them."""
import chromadb

from app.llm import generate


def retrieve(question, k=3):
    collection = chromadb.PersistentClient(path="chroma_db").get_collection("support_docs")
    return collection.query(query_texts=[question], n_results=k)["documents"][0]


def answer(messages):
    question = messages[-1]["content"]
    chunks = retrieve(question)
    context = "\n\n---\n\n".join(chunks)

    system = f"""You are a customer support assistant for an online store.
Answer ONLY using the context below. If the answer isn't there, say you'll
connect the customer to a human. Be brief and polite.

CONTEXT:
{context}"""

    return generate(system, messages), chunks
